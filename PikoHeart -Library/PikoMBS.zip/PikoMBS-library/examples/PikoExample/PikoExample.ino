// PikoExample.ino
//
// Example sketch for the PikoMBS library (which depends on PikoHeart).
// Install both PikoHeart and PikoMBS via the Arduino Library Manager
// (or by placing them in your sketchbook's libraries/ folder), then
// open this from File > Examples > PikoMBS > PikoExample.

#include <PikoMBS.h>

// Same GIF data used in MainSketch.ino
#include "piko_sleep.h"
#include "piko_idle.h"
#include "piko_walk.h"
#include "piko_jog.h"
#include "piko_sprint.h"

PikoMBS piko;

void setup() {
  Serial.begin(115200);
  while (!Serial) {};

  // Register the same GIFs, for the same states, as MainSketch.ino used
  piko.setGif(PikoHeart::idling,    idle_v2,   sizeof(idle_v2));
  piko.setGif(PikoHeart::walking,   walk_v2,   sizeof(walk_v2));
  piko.setGif(PikoHeart::running,   jog_v2,    sizeof(jog_v2));
  piko.setGif(PikoHeart::sprinting, sprint_v2, sizeof(sprint_v2));
  piko.setGif(PikoHeart::sleeping,  sleep_v2,  sizeof(sleep_v2));

  if (!piko.begin()) {
    Serial.println("Piko failed to start - check wiring!");
  }

  // Header row for the Arduino Serial Plotter, which uses the first
  // "label:value" pairs it sees to name each line in the legend.
  Serial.println("a_ave:0,a_std:0");
}

void loop() {
  piko.update();

  // Pull the live signal-processing values straight out of PikoHeart so
  // hackathon participants can see what "average" and "std" acceleration
  // actually look like as they move the watch around.
  float a_ave = piko.pikoH.getAAve();
  float a_std = piko.pikoH.getAStd();

  // Serial Plotter format: "label:value,label:value" - open
  // Tools > Serial Plotter in the Arduino IDE to see this as a live graph.
  Serial.print("a_ave:");
  Serial.print(a_ave);
  Serial.print(",a_std:");
  Serial.println(a_std);
}
