#ifndef PikoMBS_h
#define PikoMBS_h

#include <Arduino.h>
#include <SPI.h>
#include <Adafruit_GFX.h>
#include <Adafruit_ST7789.h>
#include <AnimatedGIF.h>
#include <PikoHeart.h>

//Definitions for Display
#define PIKOMBS_TFT_CS     5
#define PIKOMBS_TFT_RST    6
#define PIKOMBS_TFT_DC     7
#define PIKOMBS_SLEEP_THRESHOLD 10000
#define PIKOMBS_FPS 9
#define PIKOMBS_MAX_STEPS 200

class PikoMBS {
public:
    //State Variables
    PikoHeart::MotionState previousState;
    PikoHeart::MotionState currentState;

    //Timing Variables (instance members, NOT static -
    //each PikoMBS object needs its own independent timers)
    unsigned long lastSampleTime;
    unsigned long sampleRate;      //ensures samples every ~20ms
    unsigned long lastFrameTime;
    int frameDelay;                //non-blocking GIF frame pacing
    int fps;                       //Desired frame rate
    unsigned long sleeptimeCounter;
    unsigned long lastsleepcheckTime;
    unsigned long sleepThreshold;
    int maxSteps;

    //display variables
    bool gifPlaying;
    const uint8_t* gifData[PikoHeart::MOTIONSTATE_COUNT];
    size_t gifSize[PikoHeart::MOTIONSTATE_COUNT];

    // Constructor / Public interface
    PikoMBS();
    bool begin();
    void update();

    // Lets the hackathon sketch register each MotionState's GIF
    // (e.g. mbs.setGif(PikoHeart::walking, walk_v2, sizeof(walk_v2)); )
    void setGif(PikoHeart::MotionState state, const uint8_t* data, size_t size);

    int getSteps() const;

    // Public Objects
    PikoHeart pikoH;
    AnimatedGIF gif;

private:
    // Private methods
    void drawProgressBar(int steps);
    static void GIFDraw(GIFDRAW *pDraw);

    // AnimatedGIF's callback is a plain C function pointer, so it can't be a
    // normal (non-static) method. We stash a pointer to "the instance whose
    // GIF is currently playing" here so the static callback can reach
    // instance data (tft, steps) via self->... This assumes one GIF plays
    // at a time per PikoMBS object, which matches how update() is used.
    static PikoMBS* activeInstance;

    // Private objects - accelerometer, filter, and stats now live inside
    // PikoHeart (pikoH above), not here. PikoMBS only owns display state.
    Adafruit_ST7789 tft;
};

#endif
