#include "PikoMBS.h"

// Definition (not just declaration) of the static self-pointer used by
// the GIFDraw callback. Every static member needs exactly one definition
// like this in a .cpp file, or you'll get a linker error.
PikoMBS* PikoMBS::activeInstance = nullptr;

PikoMBS::PikoMBS()
  : previousState(PikoHeart::NONE),
    currentState(PikoHeart::NONE),
    lastSampleTime(0),
    sampleRate(20),
    lastFrameTime(0),
    frameDelay(0),
    fps(PIKOMBS_FPS),
    sleeptimeCounter(0),
    lastsleepcheckTime(0),
    sleepThreshold(PIKOMBS_SLEEP_THRESHOLD),
    maxSteps(PIKOMBS_MAX_STEPS),
    gifPlaying(false),
    pikoH(),
    gif(),
    tft(PIKOMBS_TFT_CS, PIKOMBS_TFT_DC, PIKOMBS_TFT_RST)
{
  // gifData/gifSize start empty - the hackathon sketch fills these in
  // with setGif() for each MotionState before calling begin(), e.g.:
  //   mbs.setGif(PikoHeart::walking, walk_v2, sizeof(walk_v2));
  for (int i = 0; i < PikoHeart::MOTIONSTATE_COUNT; i++) {
    gifData[i] = nullptr;
    gifSize[i] = 0;
  }
}

void PikoMBS::setGif(PikoHeart::MotionState state, const uint8_t* data, size_t size) {
  if (state < 0 || state >= PikoHeart::MOTIONSTATE_COUNT) return; // guards against a bad index
  gifData[state] = data;
  gifSize[state] = size;
}

int PikoMBS::getSteps() const {
  return pikoH.steps;
}

bool PikoMBS::begin() {
  bool ok = true;

  // PikoHeart now owns and initialises the accelerometer itself.
  if (!pikoH.begin()) {
    ok = false;
  }

  currentState = PikoHeart::idling;
  previousState = PikoHeart::NONE; // ensures the first GIF actually loads on the first update()

  // Initialize display
  tft.init(240, 240);  // Use your screen resolution
  tft.setRotation(2);  // Adjust rotation if needed
  tft.fillScreen(ST77XX_BLACK);
  tft.setTextColor(ST77XX_WHITE);
  tft.setTextSize(2);
  tft.setCursor(10, 10);
  tft.invertDisplay(false);

  // Initialize GIF decoder
  gif.begin();

  return ok;
}

void PikoMBS::update() {
  unsigned long now = millis();

  // Sample the accelerometer roughly every sampleRate ms
  if (now - lastSampleTime >= sampleRate) {
    lastSampleTime = now;

    // PikoHeart handles reading, filtering, and running-stats internally.
    pikoH.update();

    // PikoMBS still drives *when* motion gets classified and steps counted,
    // using the results PikoHeart just produced.
    currentState = pikoH.determineMovementType(pikoH.getAAve(), pikoH.getAStd());
    pikoH.countSteps(pikoH.getAFiltered(), currentState);
  }

  // Idle-to-sleep transition
  if (currentState == PikoHeart::idling) {
    sleeptimeCounter = sleeptimeCounter + now - lastsleepcheckTime;
    if (sleeptimeCounter >= sleepThreshold) {
      currentState = PikoHeart::sleeping;
    }
    lastsleepcheckTime = now;
  } else {
    sleeptimeCounter = 0;
    lastsleepcheckTime = now;
  }

  // If the motion state changed, swap in the matching GIF
  if (currentState != previousState) {
    gif.close();
    if (gifData[currentState] != nullptr &&
        gif.open((uint8_t*)gifData[currentState], gifSize[currentState], GIFDraw)) {
      gifPlaying = true;
      lastFrameTime = now;
      frameDelay = 0;
      previousState = currentState;
    } else {
      Serial.println("Failed to open GIF");
      gifPlaying = false;
    }
  }

  // Non-blocking GIF frame playback, paced to ~fps
  if (gifPlaying && now - lastFrameTime >= (unsigned long)(1000 / fps)) {
    activeInstance = this; // let the static callback reach this object's tft/steps
    int result = gif.playFrame(false, &frameDelay);
    lastFrameTime = now;
    drawProgressBar(pikoH.steps);
    if (result == 0) {
      gif.reset(); // loop the GIF
    }
  }
}

void PikoMBS::GIFDraw(GIFDRAW *pDraw) {
  PikoMBS* self = activeInstance;
  if (self == nullptr) return;

  if (pDraw->y >= self->tft.height() - 37) return; // keeps clear of the loading bar

  static uint16_t lineBuffer[320];

  uint8_t *s = pDraw->pPixels;
  uint8_t *pal = (uint8_t *)pDraw->pPalette;

  for (int x = 0; x < pDraw->iWidth; x++) {
    if (pDraw->ucHasTransparency && *s == pDraw->ucTransparent) {
      lineBuffer[x] = self->tft.color565(0, 0, 0);
      s++;
      continue;
    }
    uint8_t index = *s++;
    lineBuffer[x] = self->tft.color565(pal[index * 3], pal[index * 3 + 1], pal[index * 3 + 2]);
  }

  self->tft.drawRGBBitmap(pDraw->iX, pDraw->iY + pDraw->y, lineBuffer, pDraw->iWidth, 1);

  if (pDraw->y == (pDraw->iHeight - 1)) {
    self->tft.setTextColor(ST77XX_WHITE, ST77XX_WHITE);
    self->tft.setTextSize(2);
    self->tft.setCursor(10, 10);
    self->tft.print(String(self->pikoH.steps));
  }
}

void PikoMBS::drawProgressBar(int steps) {
  static int lastFillWidth = -1;

  int barWidth = 160;
  int barHeight = 18;
  int thickness = 2;
  int bottomPadding = 15;
  int x = (tft.width() - barWidth) / 2;
  int y = tft.height() - barHeight - bottomPadding;

  uint16_t barColor = tft.color565(216, 217, 217);

  int clampedSteps = constrain(steps, 0, maxSteps);
  int fillInset = thickness;
  int fillWidth = map(clampedSteps, 0, maxSteps, 0, barWidth - 2 * fillInset);

  if (fillWidth == lastFillWidth) return; // skip redraw when nothing changed
  lastFillWidth = fillWidth;

  for (int i = 0; i < thickness; i++) {
    tft.drawRect(x - i, y - i, barWidth + 2 * i, barHeight + 2 * i, barColor);
  }

  tft.fillRect(x + fillInset, y + fillInset, barWidth - 2 * fillInset, barHeight - 2 * fillInset, ST77XX_BLACK);
  tft.fillRect(x + fillInset, y + fillInset, fillWidth, barHeight - 2 * fillInset, barColor);
}
