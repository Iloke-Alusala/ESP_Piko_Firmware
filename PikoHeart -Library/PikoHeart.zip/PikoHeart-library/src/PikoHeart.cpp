#include "PikoHeart.h"

PikoHeart::PikoHeart()
  : steps(0), stepping(0), motionType(idling),
    ax(0), ay(0), az(0), a(0), afiltered(0), a_ave(0), a_std(0),
    acce(&Wire, PIKOHEART_I2C_ACCE_ADDRESS),
    myAccelerationFilter(LOWPASS, PIKOHEART_FC),
    myAccelerationStats()
{
  exercising_Threshold = 5;
  walking_Threshold = 50;
  running_Threshold = 100;
  sprinting_Threshold = 700;
}

PikoHeart::PikoHeart(uint32_t exercising_Thres, uint32_t walking_Thres,uint32_t running_Thres,uint32_t sprinting_Thres)
  : steps(0), stepping(0), motionType(idling),
    ax(0), ay(0), az(0), a(0), afiltered(0), a_ave(0), a_std(0),
    acce(&Wire, PIKOHEART_I2C_ACCE_ADDRESS),
    myAccelerationFilter(LOWPASS, PIKOHEART_FC),
    myAccelerationStats()
{
  exercising_Threshold = exercising_Thres;
  walking_Threshold = walking_Thres;
  running_Threshold = running_Thres;
  sprinting_Threshold = sprinting_Thres;
}

bool PikoHeart::begin(){
  bool ok = true;

  if (!acce.begin()) {
    Serial.println("Initialization failed, please check the connection and I2C address - must be");
    ok = false;
  }

  Serial.print("chip id : ");
  Serial.println(acce.getID(), HEX);
  acce.setRange(/*range = */DFRobot_LIS::eLis331hh_12g);
  acce.setAcquireRate(/*rate = */DFRobot_LIS::eNormal_50HZ);

  myAccelerationStats.setWindowSecs(PIKOHEART_WINDOW);

  return ok;
}

void PikoHeart::update(){
  //Acceleration Raw Data
  ax = acce.readAccX();
  ay = acce.readAccY();
  az = acce.readAccZ();

  a = getMagnitude(ax, ay, az) - 1000;

  //Filters through Lowpass to remove noise
  myAccelerationFilter.input(a);
  afiltered = myAccelerationFilter.output();

  //Get running statistics
  myAccelerationStats.input(afiltered);
  a_ave = myAccelerationStats.mean();
  a_std = myAccelerationStats.sigma();

  //NOTE: motion classification and step counting are intentionally NOT
  //done here. Call determineMovementType(getAAve(), getAStd()) and then
  //countSteps(getAFiltered(), motionType) yourself after update().
}

float PikoHeart::getMagnitude(int32_t x, int32_t y, int32_t z){
  return sqrt((float)x*x + (float)y*y + (float)z*z);
}

PikoHeart::MotionState PikoHeart::determineMovementType(float ave, float std){

  if(std>exercising_Threshold){
    if(ave>sprinting_Threshold){
      return sprinting;
    }
    else if(ave>running_Threshold){
      return running;
    }
    else if(ave>walking_Threshold){
      return walking;
    }
  }
  return idling;
}

void PikoHeart::countSteps(float a, PikoHeart::MotionState movementType){
  switch(movementType){
    case idling:
      return;
    case walking:
      takeStep(a, walking_Threshold);
      break;
    case running:
      takeStep(a, running_Threshold);
      break;
    case sprinting:
      takeStep(a, sprinting_Threshold);
      break;
  }
  return;
}

void PikoHeart::takeStep(float a, int threshold){
  if (a>threshold+20 && !stepping){
      steps = steps+1;
      stepping = true;
    }
    if (a<threshold+20){
      stepping = false;
    }
    return;
}

float PikoHeart::getAFiltered() const { return afiltered; }
float PikoHeart::getAAve() const { return a_ave; }
float PikoHeart::getAStd() const { return a_std; }
