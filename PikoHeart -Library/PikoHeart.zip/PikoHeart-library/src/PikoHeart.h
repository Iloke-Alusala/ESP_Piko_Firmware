#ifndef PikoAccelerate_h
#define PikoAccelerate_h

#include "Arduino.h"
#include <stdint.h>
#include <math.h>
#include <DFRobot_LIS.h>
#include <FiltersFromGit.h>

//Definitions for processing and I2C - kept here since they're PikoHeart's
//own sensor/filter setup now, not PikoMBS's
#define PIKOHEART_FC 15
#define PIKOHEART_WINDOW 2
#define PIKOHEART_I2C_ACCE_ADDRESS 0x18

class PikoHeart
{
//*********************************************************************************************************** */
    public:

    enum MotionState {
    NONE = -1,
    idling=0,
    walking=1,
    running=2,
    sprinting=3,
    sleeping=4,
    MOTIONSTATE_COUNT};

    uint32_t exercising_Threshold;
    uint32_t walking_Threshold;
    uint32_t running_Threshold;
    uint32_t sprinting_Threshold;

    int steps;
    bool stepping;
    MotionState motionType;

    PikoHeart();
    PikoHeart(uint32_t exercising_Thres, uint32_t walking_Thres,uint32_t running_Thres,uint32_t sprinting_Thres);

    // Initialises the accelerometer and the running-statistics window.
    // Must be called once (e.g. from the sketch's setup()) before update().
    bool begin();

    // Reads the accelerometer, low-pass filters it, and updates the
    // running mean/std. Does NOT classify motion or count steps -
    // call determineMovementType()/countSteps() yourself afterwards,
    // using getAAve()/getAStd()/getAFiltered().
    void update();

    MotionState determineMovementType(float ave, float std);
    void countSteps(float a, MotionState movementType);
    float getAFiltered() const;
    float getAAve() const;
    float getAStd() const;
//*********************************************************************************************************** */
    private:

    int32_t ax, ay, az;
    float a, afiltered, a_ave, a_std;

    float getMagnitude(int32_t x, int32_t y, int32_t z);
    void takeStep(float a, int threshold);

    // Sensor + signal-processing objects, now owned by PikoHeart rather
    // than by PikoMBS, since PikoHeart is responsible for producing
    // afiltered/a_ave/a_std end-to-end.
    DFRobot_LIS331HH_I2C acce;
    FilterOnePole myAccelerationFilter;
    RunningStatistics myAccelerationStats;

};

#endif
