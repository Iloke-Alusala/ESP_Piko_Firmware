// PikoHeartExample.ino
//
// Minimal example: uses PikoHeart on its own (no display) to read
// acceleration, classify motion, and count steps, printing results
// to the Serial Monitor / Serial Plotter.

#include <PikoHeart.h>

PikoHeart heart;

void setup() {
  Serial.begin(115200);
  while (!Serial) {};

  if (!heart.begin()) {
    Serial.println("PikoHeart failed to start - check wiring!");
  }

  // Header row for the Arduino Serial Plotter legend
  Serial.println("a_ave:0,a_std:0");
}

void loop() {
  heart.update();

  PikoHeart::MotionState motion = heart.determineMovementType(heart.getAAve(), heart.getAStd());
  heart.countSteps(heart.getAFiltered(), motion);

  Serial.print("a_ave:");
  Serial.print(heart.getAAve());
  Serial.print(",a_std:");
  Serial.println(heart.getAStd());
}
